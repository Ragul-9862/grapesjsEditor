import React from "react";

const GraphEditor = () => {
  return (
    <div className="graph-editor-ui">
      {/* Add your graph UI buttons, tabs, tools here */}
      <h4>Graph Editor UI</h4>
      <p>This area will contain tools for graph editing.</p>
    </div>
  );
};

export default GraphEditor;
