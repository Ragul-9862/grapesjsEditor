

const Layout = () => {
    return (
       
            <div className="col-10 col-md-10" >
                <div className='layout-body'>

                </div>
            </div>
      
    )
}

export default Layout
