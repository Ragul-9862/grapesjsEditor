import React from 'react'

const Footer = () => {
  return (
    <div className='text-center mt-3'>
    Footer
    </div>
  )
}

export default Footer
