

const Sidebar = () => {
  return (
    
      <div className="col-2 col-md-2">
        {/* Blocks */}
        <div className="sidebar">
          <div id="blocks" className="dropdown-area open"></div>
        </div>
      </div>
    
  )
}

export default Sidebar
