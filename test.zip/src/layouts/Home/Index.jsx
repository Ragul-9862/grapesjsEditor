import HomeLayout from './HomeLayout'

const Index = () => {
  return (
    <div>
      <HomeLayout/>
    </div>
  )
}


export default Index