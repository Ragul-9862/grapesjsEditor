import  Index from '../layouts/Home/Index'

 const Home = () => {
    return (
        <div>
            <Index/>
        </div>
            

    )
}


export default Home